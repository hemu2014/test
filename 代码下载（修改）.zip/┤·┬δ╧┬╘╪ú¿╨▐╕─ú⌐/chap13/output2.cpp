﻿// 写入输出文件流（追加到末尾）

#include <fstream>
#include <iostream>

using namespace std;

int main()
{
    ofstream fos("HELLO", ios_base::app);    // 以追加模式打开"HELLO"

    if (!fos)
        cerr << "\a无法打开文件\"HELLO\"。\n";
    else {
        fos << "Fine, thanks.\n";
        fos << "And you?\n";
    }
}