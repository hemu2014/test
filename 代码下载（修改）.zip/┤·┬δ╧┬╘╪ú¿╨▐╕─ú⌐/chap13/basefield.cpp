﻿// 基数的设置

#include <iostream>

using namespace std;

int main()
{
    int n, flag;
    cout << "整数值：";
    cin >> n;
    cout << "基数（0…不显示／1…显示）：";
    cin >> flag;

    if (flag) cout.setf(ios_base::showbase);
    cout.setf(ios_base::oct, ios_base::basefield);  cout << n << '\n';    // 八进制
    cout.setf(ios_base::dec, ios_base::basefield);  cout << n << '\n';    // 十进制
    cout.setf(ios_base::hex, ios_base::basefield);  cout << n << '\n';    // 十六进制
}