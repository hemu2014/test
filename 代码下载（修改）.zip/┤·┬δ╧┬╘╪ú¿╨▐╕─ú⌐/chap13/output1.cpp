﻿// 写入输出文件流

#include <fstream>
#include <iostream>

using namespace std;

int main()
{
    ofstream fos("HELLO");    // 将"HELLO"作为输出流打开

    if (!fos)
        cerr << "\a无法打开文件\"HELLO\"。\n";
    else {
        fos << "Hello!\n";
        fos << "How are you?\n";
    }
}