﻿// 将圆周率写入文件并读取（文本模式）

#include <iomanip>
#include <fstream>
#include <iostream>

using namespace std;

int main()
{
    double pi = 3.14159265358979323846264338327950288;

    ofstream fos("pi.txt");
    if (!fos)
        cout << "\a无法打开文件。\n";
    else {
        fos << pi;
        fos.close();
    }

    ifstream fis("pi.txt");
    if (!fis)
        cout << "\a无法打开文件。\n";
    else {
        fis >> pi;
        cout << "pi的值是" << fixed << setprecision(20) << pi << "。\n";
        fis.close();
    }
}