﻿// 清空文件内容

#include <string>
#include <fstream>
#include <iostream>

using namespace std;

//--- 清空名为filename的文件内容 ---//
bool file_truncate(const char* filename)
{
    ifstream fis(filename);         // 作为输入流打开
    if (fis) {
        fis.close();
        ofstream fos(filename);     // 作为输出流打开
        return fos.is_open();       // 打开是否成功？
    }
    return false;
}

int main()
{
    string file_name;
    cout << "想要清空内容的文件名称：";
    cin >> file_name;

    if (file_truncate(file_name.c_str()))
        cout << "已清空内容。\n";
    else
        cout << "该名称的文件不存在，或清空失败。\n";
}