﻿// 标志的设置与恢复

#include <iostream>

using namespace std;

//--- 将double型数组的所有元素以#######.##格式每行显示1个元素 ---//
void put_ary(double ary[], int n)
{
    // 要设置的格式（右对齐＋十进制＋固定小数点表示法）
    ios_base::fmtflags flags = ios_base::right | ios_base::dec | ios_base::fixed;

    // 保存当前的格式和最小宽度
    ios_base::fmtflags old_flags = cout.flags();    // 当前格式
    streamsize old_size = cout.width();             // 当前最小宽度

    // 设置精度并保存当前精度
    streamsize old_prec = cout.precision(2);        // 精度为2位

    for (int i = 0; i < n; i++) {
        cout.width(10);              // 将最小宽度设置为10
        cout.flags(flags);           // 将格式设置为flags
        cout << ary[i] << '\n';
    }

    cout.flags(old_flags);      // 恢复标志
    cout.width(old_size);       // 恢复最小宽度
    cout.precision(old_prec);   // 恢复精度
}

int main()
{
    double a[] = {1234.235, 5568.6205, 78999.312};

    cout << 0.00001234567890 << "\n\n";    // 正常显示

    put_ary(a, sizeof(a) / sizeof(a[0]));
    cout << '\n';

    cout << 0.00001234567890 << '\n';    // 正常显示
}