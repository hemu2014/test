﻿// 将圆周率写入文件并读取（二进制模式）

#include <iomanip>
#include <fstream>
#include <iostream>

using namespace std;

int main()
{
    double pi = 3.14159265358979323846;

    ofstream fos("pi.bin", ios_base::binary);    // 二进制模式
    if (!fos)
        cout << "\a无法打开文件。\n";
    else {
        fos.write(reinterpret_cast<char*>(&pi), sizeof(double));
        fos.close();
    }

    ifstream fis("pi.bin", ios_base::binary);    // 二进制模式
    if (!fis)
        cout << "\a无法打开文件。\n";
    else {
        fis.read(reinterpret_cast<char*>(&pi), sizeof(double));
        cout << "pi的值是" << fixed << setprecision(20) << pi << "。\n";
        fis.close();
    }
}