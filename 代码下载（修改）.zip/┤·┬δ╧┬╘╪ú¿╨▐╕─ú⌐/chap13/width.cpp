﻿// 对流的宽度进行设置

#include <iostream>

using namespace std;

int main()
{
    char str[10];

    cout << "请输入一个少于10个字符的字符串：";
    cin.width(10);
    cin >> str;

    cout << "str = ";  cout.width(12);  cout << str << '\n';
    cout << "str = "                         << str << '\n';
}