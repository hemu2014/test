﻿// 读取两个整数值并显示它们的加减乘除结果

#include <iostream>

using namespace std;

int main()
{
    int x;      // 用于加减乘除的值
    int y;      // 用于加减乘除的值

    cout << "对x和y进行加减乘除运算。\n";

    cout << "请输入x和y的值：";    // 提示输入x和y的值
    cin >> x >> y;                // 读取整数到x和y

    cout << "x + y的结果是" << x + y << "。\n";  // 显示x + y的结果
    cout << "x - y的结果是" << x - y << "。\n";  // 显示x - y的结果
    cout << "x * y的结果是" << x * y << "。\n";  // 显示x * y的结果
    cout << "x / y的结果是" << x / y << "。\n";  // 显示x / y的结果（商）
    cout << "x % y的结果是" << x % y << "。\n";  // 显示x % y的结果（余数）
}