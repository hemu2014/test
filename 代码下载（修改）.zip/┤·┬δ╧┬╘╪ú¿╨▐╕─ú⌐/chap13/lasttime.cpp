﻿// 显示程序上次运行的日期和时间

#include <ctime>
#include <fstream>
#include <iostream>

using namespace std;

char fname[] = "lasttime.txt";              // 文件名

//--- 获取并显示上次的日期和时间 ---//
void get_data()
{
    ifstream fis(fname);                    // 输入流

    if (fis.fail())
        cout << "这是您第一次运行本程序呢。\n";
    else {
        int year, month, day, h, m, s;
        fis >> year >> month >> day >> h >> m >> s;
        cout << "上次运行是在" << year << "年" << month << "月" << day << "日"
             << h << "时" << m << "分" << s << "秒。\n";
    }
}

//--- 写入本次的日期和时间 ---//
void put_data()
{
    ofstream fos(fname);                    // 输出流

    if (fos.fail())
        cout << "\a无法打开文件。\n";
    else {
        time_t t = time(NULL);
        struct tm* local = localtime(&t);
        fos << local->tm_year + 1900 << ' ' << local->tm_mon + 1 << ' '
            << local->tm_mday        << ' ' << local->tm_hour    << ' '
            << local->tm_min         << ' ' << local->tm_sec     << '\n';
    }
}

int main()
{
    get_data();    // 获取并显示上次的日期和时间

    put_data();    // 写入本次的日期和时间
}