﻿// 确认文件是否存在（其二）

#include <string>
#include <fstream>
#include <iostream>

using namespace std;

//--- 判断名为filename的文件是否存在 ---//
bool file_exist(const char* filename)
{
    ifstream fis(filename);    // 作为输入流打开
    return !fis.fail();        // 打开是否成功？
}

int main()
{
    string file_name;
    cout << "想要确认存在性的文件名称：";
    cin >> file_name;

    cout << "该文件"
         << (file_exist(file_name.c_str()) ? "存在。\n" : "不存在。\n");
}