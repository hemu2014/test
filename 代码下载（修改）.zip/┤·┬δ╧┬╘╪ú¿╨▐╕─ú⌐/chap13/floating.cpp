﻿// 浮点数的格式

#include <iostream>

using namespace std;

int main()
{
    int precision;    // 精度
    double x;         // 要显示的值

    cout << "请输入实数：";
    cin >> x;

    cout << "请输入精度：";
    cin >> precision;

    cout.precision(precision);    // 精度一直有效

    cout.setf(ios_base::scientific, ios_base::floatfield);
    cout << "科学计数法形式：" << x << '\n';

    cout.setf(ios_base::fixed, ios_base::floatfield);
    cout << "固定小数位形式：" << x << '\n';

    cout.setf(0, ios_base::floatfield);    
    cout << "普通显示：" << x << '\n';
}