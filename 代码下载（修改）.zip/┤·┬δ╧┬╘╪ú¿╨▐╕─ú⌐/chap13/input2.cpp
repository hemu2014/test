﻿// 从输入文件流按行读取字符串并显示

#include <string>
#include <fstream>
#include <iostream>

using namespace std;

int main()
{
    ifstream fis("HELLO");    // 将"HELLO"作为输入流打开

    if (!fis)
        cerr << "\a无法打开文件\"HELLO\"。\n";
    else {
        while (true) {
            string text;
            getline(fis, text);    // 从流中读取一行
            if (!fis) break;
            cout << text << '\n';  // 将该字符串显示在屏幕上
        }
    }
}