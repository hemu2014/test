﻿// concat……文件复制

#include <fstream>
#include <iostream>

using namespace std;

//--- 将src的输入输出到dst ---//
void copy(istream& src, ostream& dst)
{
    char ch;

    src >> noskipws;
    while (src >> ch)
        dst << ch;
}

int main(int argc, char** argv)
{
    ifstream is;

    if (argc < 2)
        copy(cin, cout);        // 将标准输入复制到标准输出
    else {
        while (--argc > 0) {
            ifstream fs(*++argv);
            if (!fs)
                cerr << "\a无法打开文件" << *argv << "。\n";
            else
                copy(fs, cout);    // 将流fs复制到标准输出
        }
    }
}