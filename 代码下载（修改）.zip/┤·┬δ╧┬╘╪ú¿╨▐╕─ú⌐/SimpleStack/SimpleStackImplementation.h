// ��ջ ���ʵ��

#ifndef ___Class_SimpleStackImplementation
#define ___Class_SimpleStackImplementation

//--- ���캯�� ---//
template<class Type>
SimpleStack<Type>::SimpleStack(int sz) : size(sz), ptr(0)
{
	stk = new Type[size];
}

//--- �������� ---//
template<class Type>
SimpleStack<Type>::~SimpleStack()
{
	delete[] stk;
}

//--- ��ջ ---//
template<class Type>
Type& SimpleStack<Type>::push(const Type& x)
{							
	if (ptr >= size)								// ջ����
		throw Overflow();
	return stk[ptr++] = x;
}

//--- ��ջ ---//
template<class Type>
Type SimpleStack<Type>::pop()
{
	if (ptr <= 0)									// ջ�ѿ�
		throw Empty();
	return stk[--ptr];
}

#endif