﻿// 派生类对象中包含的虚基类部分对象仅有一个

#include <iostream>

using namespace std;

//===== 类A =====//
class A {
    int a;
public:
    A() : a(0) { }                     // 构造函数
    int  get_a()      { return a; }     // a的getter
    void set_a(int v) { a = v;    }     // a的setter
};

//===== 类X =====//
class X : virtual public A {
public:
    int  get_a()      { return A::get_a(); }
    void set_a(int v) { A::set_a(v); }
};

//===== 类Y =====//
class Y : virtual public A {
public:
    int  get_a()      { return A::get_a(); }
    void set_a(int v) { A::set_a(v); }
};

//===== 类Z =====//
class Z : public X, public Y {

    // 这里不定义任何内容

};

int main()
{
    Z obj;        // 通过默认构造函数，A::a 被初始化为0

    cout << "X::get_a() = " << obj.X::get_a() << '\n';
    cout << "Y::get_a() = " << obj.Y::get_a() << '\n';

    obj.X::set_a(5);

    cout << "X::get_a() = " << obj.X::get_a() << '\n';
    cout << "Y::get_a() = " << obj.Y::get_a() << '\n';
}