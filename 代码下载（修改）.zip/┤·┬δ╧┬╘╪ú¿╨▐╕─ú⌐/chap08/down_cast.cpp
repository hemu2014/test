﻿// 多重继承与向下转型中的指针

#include <iostream>

using namespace std;

class A {
    int a;
};

class B {
    int b;
};

class C : public A, public B {
    int c;
};

int main()
{
    C c;
    A* ptr_a = &c;      // ptr_a指向c
    B* ptr_b = &c;      // ptr_b指向c

    cout << "ptr_a = " << ptr_a << '\n';    // 显示指向c的ptr_a的值
    cout << "ptr_b = " << ptr_b << '\n';    // 显示指向c的ptr_b的值
    cout << "&c    = " << &c << '\n';       // 显示c的地址
}