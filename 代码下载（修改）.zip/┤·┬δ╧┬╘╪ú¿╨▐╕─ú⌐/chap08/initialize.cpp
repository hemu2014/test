﻿// 虚基类与非虚基类的构造与析构

#include <iostream>

using namespace std;

class V1 {
public:
    V1() { cout << "构造V1\n"; }
    ~V1() { cout << "析构V1\n"; }
};

class V2 {
public:
    V2() { cout << "构造V2\n"; }
    ~V2() { cout << "析构V2\n"; }
};

class X : virtual public V1, virtual public V2 {
public:
    X() { cout << "构造Ｘ\n"; }
    ~X() { cout << "析构Ｘ\n"; }
};

class Y : virtual public V2, virtual public V1 {
public:
    Y() { cout << "构造Ｙ\n"; }
    ~Y() { cout << "析构Ｙ\n"; }
};

class Z : public X, public Y {
public:
    Z() { cout << "构造Ｚ\n"; }
    ~Z() { cout << "析构Ｚ\n"; }
};

int main()
{
    Z dummy;
    cout << "--------\n";
}