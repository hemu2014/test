﻿// 多重继承（基类的初始化・模糊性的控制验证）

#include <iostream>

using namespace std;

//===== 基类1 =====//
class Base1 {
public:
    int x;

    Base1(int a = 0) : x(a) {                // 构造函数
        cout << "Base1::x 初始化为 " << x << "。\n";
    }

    void print() { cout << "这是Base1类：x = " << x << '\n'; }
};

//===== 基类2 =====//
class Base2 {
public:
    int x;

    Base2(int a = 0) : x(a) {                // 构造函数
        cout << "Base2::x 初始化为 " << x << "。\n";
    }

    void print() { cout << "这是Base2类：x = " << x << '\n'; }
};

//===== 派生类 =====//
class Derived : public Base1, public Base2 {
    int y;

public:
    Derived(int a, int b, int c) : y(c), Base2(a), Base1(b) { // 构造函数
        cout << "Derived::y 初始化为 " << y << "。\n";
    }

    void func(int a, int b) {
    //  x = a;              // 错误：模糊
        Base1::x = a;
        Base2::x = b;
    }
};

int main()
{
    Derived z(1, 2, 3);

    z.func(1, 2);
//  z.print();              // 错误：模糊
    z.Base1::print();
    z.Base2::print();
}