﻿// 拥有虚基类的类对象的大小

#include <iostream>

using namespace std;

class A             { int x; } a;
class B : A         { int x; } b;
class C : virtual A { int x; } c;

int main()
{
	cout << "sizeof(A) = " << sizeof(A) << '\n';
	cout << "sizeof(B) = " << sizeof(B) << '\n';
	cout << "sizeof(C) = " << sizeof(C) << '\n';
}