﻿// 简易数组类（虚基类的应用示例）

#include <iostream>

using namespace std;

//===== 缓冲区 =====//
class Buf {
    int a[5];
protected:
    int  element(int i) const { return a[i]; }        // 返回a[i]
    int& element(int i)       { return a[i]; }        // 返回a[i]的引用
};

//===== 只读缓冲区 =====//
class InBuf : virtual public Buf {
public:
    int get(int i) const { return element(i); }       // 读取a[i]
};

//===== 只写缓冲区 =====//
class OutBuf : virtual public Buf {
public:
    void put(int i, int v) { element(i) = v; }        // 写入a[i]
};

//===== 可读写缓冲区 =====//
class IOBuf : public InBuf, public OutBuf {

    // 这里不定义任何内容

};

int main()
{
    IOBuf a;

    for (int i = 0; i < 5; i++)
        a.put(i, i * 10);

    for (int i = 0; i < 5; i++)
        cout << a.get(i) << " ";
    cout << '\n';
}