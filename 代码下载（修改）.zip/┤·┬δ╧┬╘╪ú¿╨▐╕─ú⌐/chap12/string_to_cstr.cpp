﻿// 将string转换为C语言字符串

#include <string>
#include <cstring>
#include <iostream>

using namespace std;

int main()
{
    char cst[100];         // 包含空字符最多100个字符
    string str;

    cout << "请输入字符串：";
    cin >> str;

    strcpy(cst, str.c_str());    // 将str转换为C语言字符串并复制到cst

    cout << "cst = " << cst << '\n';
    cout << "str = " << str << '\n';
}