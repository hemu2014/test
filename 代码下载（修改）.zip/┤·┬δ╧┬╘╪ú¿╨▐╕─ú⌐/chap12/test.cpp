﻿// 处理string型字符串的程序

#include <vector>
#include <string>
#include <iostream>

using namespace std;

//--- 将指针指向的字符串数组转换为vector<string> ---//
vector<string> strptary_to_vec(char** p, int n)
{
	vector<string> temp;
	for (int i = 0; i < n; i++)
		temp.push_back(p[i]);
	return temp;
}

int main(int argc, char** argv)
{
	// 将命令行字符串转换为vector<string>
	vector<string> arg = strptary_to_vec(argv, argc);			// 转换

	for (vector<string>::size_type i = 0; i < arg.size(); i++)	// 显示
		cout << "arg[" << i << "] = " << arg[i] << '\n';

	string s1, s2;

	cout << "字符串s1 : ";  getline(cin, s1);
	cout << "字符串s2 : ";  getline(cin, s2);

	//--- 通过下标运算符进行遍历 ---//
	cout << "s1 = ";
	for (string::size_type i = 0; i < s1.length(); i++)
		cout << s1[i];
	cout << '\n';

	//--- 通过迭代器进行遍历 ---//
	cout << "s2 = ";
	for (string::const_iterator i = s2.begin(); i != s2.end(); i++)
		cout << *i;
	cout << '\n';

	//--- 查找字符串中包含的子字符串 ---//
	string::size_type idx = s1.find(s2);

	if (idx == string::npos)
		cout << "s2不包含在s1中。\n";
	else
		cout << "s2包含在s1的第" << (idx + 1) << "个字符位置。\n";
}