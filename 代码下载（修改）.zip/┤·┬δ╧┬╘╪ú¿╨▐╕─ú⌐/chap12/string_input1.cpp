﻿// 读取名字并打招呼

#include <string>
#include <iostream>

using namespace std;

int main()
{
    string name;            // 名字

    cout << "请输入姓名：";  // 提示输入名字
    cin >> name;            // 读取名字（忽略空格）

    cout << "你好，" << name << "。\n";  // 打招呼
}