﻿// 字符串的数组的向量

#include <string>
#include <vector>
#include <iostream>

using namespace std;

//--- 通过指针将字符串的数组转换为vector<string> ---//
vector<string> strptary_to_vec(char** p, int n)
{
    vector<string> temp;
    for (int i = 0; i < n; i++)
        temp.push_back(p[i]);
    return temp;
}

int main(int argc, char** argv)
{
    vector<string> s1 = strptary_to_vec(argv, argc);            // 转换
    for (vector<string>::size_type i = 0; i < s1.size(); i++)    // 显示
        cout << "s1[" << i << "] = " << s1[i] << '\n';
}