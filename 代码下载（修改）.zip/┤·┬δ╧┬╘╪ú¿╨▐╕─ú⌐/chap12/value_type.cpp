﻿// 表示string型和wstring型的元素类型

#include <string>
#include <iostream>
#include <typeinfo>

using namespace std;

int main()
{
   cout << " string型的元素类型是" << typeid( string::value_type).name() << "。\n";
   cout << "wstring型的元素类型是" << typeid(wstring::value_type).name() << "。\n";
}