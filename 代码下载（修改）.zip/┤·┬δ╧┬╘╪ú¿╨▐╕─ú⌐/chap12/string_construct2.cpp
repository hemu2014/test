﻿// string的构建示例（其二）

#include <string>
#include <iostream>

using namespace std;

int main()
{
    string s1("ABCDEFGHIJK");        // 字符串"ABCDEFGHIJK"


    //--- 第二个参数不正确的示例 ---//
    // string sa(s1, 55, 3);         // 不存在第55个字符，会抛出out_of_range异常
    // string sb(s1, -5, 2);         // 同样会抛出out_of_range异常

    // cout << "sa = " << sa << '\n';
    // cout << "sb = " << sb << '\n';


    //--- 第三个参数可以是负值 ---//
    string sx(s1, 2, 128);           // 不存在128个字符，所以会复制到末尾字符
    string sy(s1, 2, -5);            // 会复制到末尾字符
    string sz(s1, 2, string::npos);  // 会复制到末尾字符

    cout << "sx = " << sx << '\n';
    cout << "sy = " << sy << '\n';
    cout << "sz = " << sz << '\n';


    //--- 不能用字符初始化，但可以赋值 ---//
    // string sc1 = 'X';    // 错误：不能用单个字符初始化
    string sc2;
    sc2 = 'X';            // 正确：可以用单个字符赋值

    // cout << "sc1 = " << sc1 << '\n';
    cout << "sc2 = " << sc2 << '\n';


    //--- 用二元+运算符进行连接 ---//
    string st1 = "ABC";
    string st2 = "ABC" + s1;
    string st3 = st1 + st2;
    string st4 = st1 + "UVW";
    // string st5 = "UVW" + "XYZ";            // 错误
    string st6 = st1 + "UVW" + "XYZ";
    // string st7 = "UVW" + "XYZ" + s1;       // 错误
    string st8 = "ABC" + 'D';                // 不正确：不是连接
    string st9 = st1 + 'D';
    
    cout << "st1 = " << st1 << '\n';
    cout << "st2 = " << st2 << '\n';
    cout << "st3 = " << st2 << '\n';
    cout << "st4 = " << st4 << '\n';
    // cout << "st5 = " << st5 << '\n';
    cout << "st6 = " << st6 << '\n';
    // cout << "st7 = " << st7 << '\n';
    cout << "st8 = " << st8 << '\n';
    cout << "st9 = " << st9 << '\n';

    //--- 用复合赋值运算符+=进行连接 ---//
    st9 += st1;           // 连接string类型字符串
    st9 += "ABC";         // 连接C语言字符串
    st9 += 'D';           // 连接单个字符

    cout << "st9 = " << st9 << '\n';
}