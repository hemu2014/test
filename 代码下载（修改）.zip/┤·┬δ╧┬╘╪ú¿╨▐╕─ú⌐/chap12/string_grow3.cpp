﻿// 按指定长度在字符串末尾添加相同字符（函数模板版）

#include <string>
#include <iostream>

using namespace std;

//--- 为使字符串s达到width个字符，在其末尾填充字符ch ---*/
template <class type>
void pad_char(basic_string<type>&s, type ch,
			  typename basic_string<type>::size_type width)
{
	if (width > s.length())		// 若s的字符数已大于等于width，则不进行任何操作
		s.append(width - s.length(), ch);
}

int main()
{
	string s1 = "ABC";
	wstring s2 = L"柴田";
	wcout.imbue(std::locale("Japanese"));  // 保持"Japanese"，因是区域设置标识符

	pad_char(s1, '+',   10);
	pad_char(s2, L'＋', 10);

	cout << "s1 = " << s1 << '\n';
	wcout << "s2 = " << s2 << '\n';
}