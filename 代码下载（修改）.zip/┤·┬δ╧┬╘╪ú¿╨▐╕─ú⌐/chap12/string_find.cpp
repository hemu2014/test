﻿// 字符串的搜索

#include <string>
#include <iostream>

using namespace std;

int main()
{
    string txt, pat;

    cout << "字符串txt：";   getline(cin, txt);
    cout << "字符串pat：";   getline(cin, pat);

    string::size_type pos = txt.find(pat);
    if (pos == string::npos)
        cout << "pat不包含在txt中。\n";
    else
        cout << "pat包含在txt的第" << (pos + 1) << "个字符处。\n";
}