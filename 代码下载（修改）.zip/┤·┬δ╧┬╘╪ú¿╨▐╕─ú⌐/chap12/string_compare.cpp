﻿// 字符串大小关系的判定

#include <string>
#include <iostream>

using namespace std;

//--- 显示比较结果 ---//
void put_comp_result(int cmp)
{
    if (cmp < 0)
        cout << "更小。\n";
    else if (cmp > 0)
        cout << "更大。\n";
    else
        cout << "一致。\n";
}

int main()
{
    int n;
    string s1, s2;

    cout << "字符串s1：";         cin >> s1;
    cout << "字符串s2：";         cin >> s2;
    cout << "部分比较的字符数：";   cin >> n;

    cout << boolalpha;
    cout << "s1 == s2 " << (s1 == s2) << '\n';
    cout << "s1 != s2 " << (s1 != s2) << '\n';
    cout << "s1 <  s2 " << (s1 <  s2) << '\n';
    cout << "s1 <= s2 " << (s1 <= s2) << '\n';
    cout << "s1 >  s2 " << (s1 >  s2) << '\n';
    cout << "s1 >= s2 " << (s1 >= s2) << '\n';

    cout << "s1比s2";
    put_comp_result(s1.compare(s2));

    cout << "s1的前" << n << "个字符比s2的前" << n << "个字符";
    put_comp_result(s1.compare(0, n, s2, 0, n));

    cout << "s1比\"ABC\"";
    put_comp_result(s1.compare("ABC"));
}