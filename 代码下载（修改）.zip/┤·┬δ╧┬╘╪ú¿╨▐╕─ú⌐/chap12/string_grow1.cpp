﻿// 按指定长度在字符串末尾添加相同字符（函数版）

#include <string>
#include <iostream>

using namespace std;

//--- 为使字符串s达到width个字符，在其末尾填充字符ch ---
void pad_char(string &s, char ch, string::size_type width)
{
    if (width > s.length())    // 如果s的字符数大于等于width，则不做任何操作
        s.append(width - s.length(), ch);
}

int main()
{
    int width;
    char ch;
    string s1, s2, s3;

    cout << "将在字符串末尾填充字符，直到达到指定长度。\n";
    cout << "字符串s1 = ";   cin >> s1;
    cout << "字符串s2 = ";   cin >> s2;
    cout << "字符串s3 = ";   cin >> s3;
    cout << "指定长度   = ";   cin >> width;
    cout << "字符     = ";   cin >> ch;

    pad_char(s1, ch, width);
    pad_char(s2, ch, width);
    pad_char(s3, ch, width);

    cout << "s1 = " << s1 << '\n';
    cout << "s2 = " << s2 << '\n';
    cout << "s3 = " << s3 << '\n';
}