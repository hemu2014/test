﻿// 对字符串应用各种算法

#include <cctype>
#include <string>
#include <iostream>
#include <algorithm>
#include <functional>

using namespace std;

//--- 小写转大写 ---//
struct to_upper {
    char operator()(char c) { return toupper(c); }
};

//--- 大写转小写 ---//
struct to_lower {
    char operator()(char c) { return tolower(c); }
};

//--- 大小写反转 ---//
struct invert_case {
    char operator()(char c) {
        return islower(c) ? toupper(c) : isupper(c) ? tolower(c) : c;
    }
};

int main()
{
    string s1;
    cout << "请输入字符串：";
    cin >> s1;
    string s2(s1);

    transform(s1.begin(), s1.end(), s2.begin(), invert_case());    // 大小写反转
    cout << "大小写反转：" << s2 << '\n';

    transform(s1.begin(), s1.end(), s2.begin(), to_upper());       // 全部大写
    cout << "全部大写：" << s2 << '\n';

    transform(s1.begin(), s1.end(), s2.begin(), to_lower());       // 全部小写
    cout << "全部小写：" << s2 << '\n';

    random_shuffle(s1.begin(), s1.end());                          // 打乱顺序
    cout << "打乱顺序：" << s1 << '\n';

    sort(s1.begin(), s1.end());                                    // 升序排序
    cout << "升序排序：" << s1 << '\n';

    sort(s1.begin(), s1.end(), greater<char>());                   // 降序排序
    cout << "降序排序：" << s1 << '\n';
}