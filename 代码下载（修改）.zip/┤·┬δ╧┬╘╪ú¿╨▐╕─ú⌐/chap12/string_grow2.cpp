﻿// 以达到指定长度的方式在字符串末尾添加相同字符（函数模板版）

#include <string>
#include <iostream>

using namespace std;

//--- 以达到width个字符的方式在字符串s的末尾填充字符ch ---*/
template <class type>
void pad_char(basic_string<type>&s, type ch,
              typename basic_string<type>::size_type width)
{
    if (width > s.length())    // 如果s的字符数大于等于width则不做任何操作
        s.append(width - s.length(), ch);
}

int main()
{
    string s1 = "ABC";
    wstring s2 = L"柴田";  // 此处“柴田”是人名，保留原样
    wcout.imbue(std::locale("Japanese"));  // 此处为区域设置，保留原样

    pad_char(s1, '+',   10);
    pad_char(s2, L'＋', 10);

    cout << "s1 = " << s1 << '\n';
    wcout << "s2 = " << s2 << '\n';
}